
package Controlador;
import java.io.*;
import java.util.ArrayList;
import Model.Estudios;
import Model.Paciente;
import Model.Profesional;
import Model.Fecha;


public class ControladorArchivos {    
    //Guarda y lee Pacientes (escritura
    public void guardarPacienteARCH (ArrayList<Paciente> listadePacientes)throws IOException{
        File archivo = new File ("paciente.txt");
        FileWriter fw = new FileWriter(archivo);
        BufferedWriter br = new BufferedWriter(fw);
        int i;
        for (i=0 ; i<listadePacientes.size();i++ ){
        Paciente p = listadePacientes.get(i);
            br.append(p.getNombre()+","+p.getApellido()+","+p.getTelefono()+","+
                    p.getMail()+","+p.getObraSocial()+","+p.getDNI()+"\n");
            
             }
        br.close();
        
    }
    //lectura
    public void leePacienteARCH (ArrayList<Paciente> listadePacientes) throws IOException{
        File archivo = new File ("paciente.txt");
        if(archivo.exists()){
        FileReader fr = new FileReader (archivo);
        BufferedReader br = new BufferedReader(fr);
        String linea;
        listadePacientes.clear();
        while((linea = br.readLine()) != null){
            String[] datos = linea.split(",");
            String nombre = datos[0];
            String apellido = datos [1];
            long telefono = Long.parseLong (datos[2]);
            String mail = datos [3];
            boolean obraSocial = Boolean.parseBoolean (datos [4]);
            long dni = Long.parseLong (datos [5]);
            
            Paciente p = new Paciente(nombre,apellido,telefono,mail,obraSocial,dni);
            listadePacientes.add(p);
        }
        br.close();
        }
}
    //Guarda y lee Profesionales
    public void guardarProfesionalARCH (ArrayList<Profesional> listadeProfesionales )throws IOException{
        File archivo = new File ("profesional.txt");
        FileWriter fw = new FileWriter ( archivo);
        BufferedWriter br = new BufferedWriter(fw);
        int i;
        for (i=0; i< listadeProfesionales.size();i++){
            Profesional p = listadeProfesionales.get(i);
            br.append(p.getNombre()+","+p.getApellido()+","+
                    p.getTelefono()+","+ p.getMail()+","+ p.getMatricula()+"\n");
            
        }
        br.close();
    }
    //subir a la lista
    public void leeProfesionalesARCH (ArrayList<Profesional> listadeProfesionales )throws IOException{
        File archivo = new File ("profesional.txt");
        FileReader fr = new FileReader (archivo);
        BufferedReader br = new BufferedReader (fr);
        String linea;
        listadeProfesionales.clear();
        while ((linea = br.readLine())!=null){
            String[] datos = linea.split(",");
            String nombre = datos[0];
            String apellido = datos [1];
            long telefono = Long.parseLong(datos[2]);
            String mail = datos[3];
            long matricula = Long.parseLong(datos[4]);
            
            Profesional p = new Profesional (nombre,apellido,telefono,mail,matricula);
            listadeProfesionales.add(p);
        }
        br.close();
    }
    
    //Guarda y lee Estudios (escritura
    public void guardarEstudiosARCH (ArrayList<Estudios> listadeEstudios )throws IOException{
        File archivo = new File ("estudios.txt");
        
        FileWriter fr = new FileWriter (archivo);
        BufferedWriter br = new BufferedWriter (fr);
        int i;
        for (i=0; i< listadeEstudios.size();i++){
            Estudios e = listadeEstudios.get(i);
            
            br.append(e.getPaciente().getDNI() +","+e.getProfesional().getMatricula()
                    +","+e.getRealizacion().getDia()+"/"+ e.getRealizacion().getMes()+"/"+e.getRealizacion().getAnio()+ ","+
                    e.getEntrega().getDia()+"/"+e.getEntrega().getMes()+"/"+e.getEntrega().getAnio()
                    +","+e.getEstado()+"\n");
        }
        br.close();
        
    }
    
    public void leeEstudiosARCH (ArrayList<Paciente> listadePacientes , ArrayList<Profesional> listadeProfesionales , ArrayList<Estudios> listadeEstudios)throws IOException{
        int i;
        File archivo = new File ("estudios.txt");
        if(archivo.exists()){
        FileReader fr = new FileReader (archivo);
        BufferedReader br = new BufferedReader (fr);
        String linea;
        listadeEstudios.clear();
        while((linea = br.readLine())!=null){
            //Busca Paciente
            String[] datos= linea.split(",");
            long dnipaciente = Long.parseLong (datos[0]);
            Paciente pCarga = new Paciente();
            for (i=0;i<listadePacientes.size();i++){
                
                Paciente p = listadePacientes.get(i);
                if (p.getDNI() == dnipaciente){
                    pCarga = p;
                    break;
                }
                    
            }
            //Busca el profesional  (FALTA
            long matricula = Long.parseLong(datos[1]);
            Profesional profCarga = new Profesional();
            for (i=0;i<listadeProfesionales.size();i++){
                
                Profesional l = listadeProfesionales.get(i);
                if (l.getMatricula() == matricula){
                    profCarga = l;
                    break;
                }
                    
            }
            //fechas
            String[] fechaR = datos[2].split("/");
            int dia = Integer.parseInt(fechaR[0]);
            int mes = Integer.parseInt(fechaR[1]);
            int anio = Integer.parseInt(fechaR[2]);
            Fecha fRealizacion = new Fecha(dia,mes,anio);
            
            String[] fechaE = datos[3].split("/");
            int dia1 = Integer.parseInt(fechaE[0]);
            int mes1 = Integer.parseInt(fechaE[1]);
            int anio1 = Integer.parseInt(fechaE[2]);
            Fecha rEntrega = new Fecha(dia1,mes1,anio1);
            
            
            int estado = Integer.parseInt (datos[4]);
            
            Estudios entra = new Estudios (fRealizacion,rEntrega,pCarga,profCarga,estado);
            listadeEstudios.add(entra);
        }
        br.close();
        }
    }
 
}