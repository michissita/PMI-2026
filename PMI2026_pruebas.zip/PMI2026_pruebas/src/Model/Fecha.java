package Model;
import java.time.LocalDate;
//Se usa la libreria Date, preguntar como se aplicaria

public class Fecha {
    //variables de instancia
    private int dia;
    private int mes;
    private int anio;
    
    //constructores
   public Fecha(int dia, int mes, int anio) {
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
    }
    
    public  Fecha () {
    LocalDate hoy = LocalDate.now();
    this.dia = hoy.getDayOfMonth();
    this.mes = hoy.getMonthValue();
    this.anio= hoy.getYear();
    }
    
    
    //observadores
    public int getDia() {
        return dia;
    }
    public int getMes() {
        return mes;
    }
    public int getAnio() {
        return anio;
    }
    //modificadores
    public void setDia(int dia) {
        this.dia = dia;
    }
    public void setMes(int mes) {
        this.mes = mes;
    }
    public void setAnio(int anio) {
        this.anio = anio;
    }

    @Override
    public String toString() {
        return  dia + "," + mes + "," + anio;
    }
}